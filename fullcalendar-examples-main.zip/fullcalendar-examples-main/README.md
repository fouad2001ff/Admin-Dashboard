
# FullCalendar Example Projects

A collection of simple example projects to show how to use FullCalendar with various build setups.

Please read the README in each project subdirectory.
